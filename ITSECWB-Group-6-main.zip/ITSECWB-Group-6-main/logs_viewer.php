<?php
include 'dependencies/config.php';
include 'dependencies/auth.php';
include 'dependencies/logger.php';

require_login();
require_role(['owner', 'admin']);

$logger = new SecurityLogger($conn);

// Get filter parameters
$event_type_filter = $_GET['event_type'] ?? '';
$success_filter = $_GET['success'] ?? '';
$date_filter = $_GET['date'] ?? '';

// Build WHERE clause
$where_conditions = [];
$params = [];
$param_types = '';

if ($event_type_filter) {
    $where_conditions[] = "event_type = ?";
    $params[] = $event_type_filter;
    $param_types .= 's';
}

if ($success_filter !== '') {
    $where_conditions[] = "success = ?";
    $params[] = $success_filter;
    $param_types .= 'i';
}

if ($date_filter) {
    $where_conditions[] = "DATE(timestamp) = ?";
    $params[] = $date_filter;
    $param_types .= 's';
}

$where_clause = '';
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM security_logs $where_clause";
$count_stmt = $conn->prepare($count_query);
if (!empty($params)) {
    $count_stmt->bind_param($param_types, ...$params);
}
$count_stmt->execute();
$total_logs = $count_stmt->get_result()->fetch_assoc()['total'];
$count_stmt->close();

// Pagination
$logs_per_page = 50;
$current_page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$total_pages = ceil($total_logs / $logs_per_page);
$offset = ($current_page - 1) * $logs_per_page;

// Get logs with pagination
$logs_query = "SELECT * FROM security_logs $where_clause ORDER BY timestamp DESC LIMIT ? OFFSET ?";
$logs_stmt = $conn->prepare($logs_query);
$params[] = $logs_per_page;
$params[] = $offset;
$param_types .= 'ii';
$logs_stmt->bind_param($param_types, ...$params);
$logs_stmt->execute();
$logs_result = $logs_stmt->get_result();

// Get unique event types for filter
$event_types_query = "SELECT DISTINCT event_type FROM security_logs ORDER BY event_type";
$event_types_result = $conn->query($event_types_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Security Logs - La Frontera</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/reports.css">
    <link rel="icon" type="image/x-icon" href="images/favicon.ico">
    <style>
        .logs-container {
            max-width: 1400px;
            margin: 20px auto;
            padding: 20px;
        }
        .logs-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .logs-filters {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .filter-row {
            display: flex;
            gap: 20px;
            align-items: center;
            margin-bottom: 15px;
        }
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        .filter-group label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        .filter-group select, .filter-group input {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .filter-buttons {
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background-color: #007bff;
            color: white;
        }
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        .logs-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .logs-table table {
            width: 100%;
            border-collapse: collapse;
        }
        .logs-table th {
            background: #2c3e50;
            color: white;
            padding: 12px;
            text-align: left;
        }
        .logs-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }
        .logs-table tr:hover {
            background-color: #f8f9fa;
        }
        .event-type {
            font-weight: bold;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
        }
        .event-type.ACCESS_DENIED { background-color: #f8d7da; color: #721c24; }
        .event-type.VALIDATION_FAILURE { background-color: #fff3cd; color: #856404; }
        .event-type.AUTH_ATTEMPT { background-color: #d1ecf1; color: #0c5460; }
        .event-type.LOGIN_SUCCESS { background-color: #d4edda; color: #155724; }
        .event-type.LOGIN_FAILURE { background-color: #f8d7da; color: #721c24; }
        .event-type.ORDER_COMPLETED { background-color: #d4edda; color: #155724; }
        .event-type.ORDER_CANCELLED { background-color: #fff3cd; color: #856404; }
        .event-type.INVENTORY_ADDED { background-color: #d4edda; color: #155724; }
        .event-type.INVENTORY_DELETED { background-color: #f8d7da; color: #721c24; }
        .success-yes { color: #28a745; font-weight: bold; }
        .success-no { color: #dc3545; font-weight: bold; }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
        }
        .pagination a {
            padding: 8px 12px;
            border: 1px solid #ddd;
            text-decoration: none;
            color: #007bff;
            border-radius: 4px;
        }
        .pagination a:hover {
            background-color: #f8f9fa;
        }
        .pagination .current {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .details-cell {
            max-width: 400px;
            word-wrap: break-word;
            white-space: normal;
        }
    </style>
</head>
<body>
<div class="header">
    <div class="logo">La Frontera</div>
    <div class="search-nav">
        <a href="MenuPage.php" class="nav-item">Dashboard</a>
        <a href="reports.php" class="nav-item">Reports</a>
    </div>
    <div class="user-dropdown">
        <div class="user-icon" id="userDropdownBtn">
            <i class="fas fa-user"></i>
        </div>
        <div class="dropdown-menu" id="userDropdownMenu">
            <a href="profile.php">My Account</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
</div>

<div class="container">
    <div class="sidebar">
        <a href="MenuPage.php" class="sidebar-item"><i class="fas fa-home"></i> Home</a>
        <a href="InventoryPage.php" class="sidebar-item"><i class="fas fa-boxes"></i> Inventory</a>
        <a href="ProductPage.php" class="sidebar-item"><i class="fas fa-box"></i> Products</a>
        <a href="OrderPage.php" class="sidebar-item"><i class="fas fa-shopping-cart"></i> Orders</a>
        <a href="logs_viewer.php" class="sidebar-item active"><i class="fas fa-shield-alt"></i> Security Logs</a>
    </div>

    <div class="content">
        <div class="logs-container">
            <div class="logs-header">
                <h2><i class="fas fa-shield-alt"></i> Security Logs</h2>
                <a href="export_logs.php" class="btn btn-success">
                    <i class="fas fa-download"></i> Export CSV
                </a>
            </div>

            <div class="logs-filters">
                <form method="GET" action="logs_viewer.php">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label for="event_type">Event Type:</label>
                            <select name="event_type" id="event_type">
                                <option value="">All Events</option>
                                <?php while ($event_type = $event_types_result->fetch_assoc()): ?>
                                    <option value="<?= htmlspecialchars($event_type['event_type']) ?>" 
                                            <?= $event_type_filter === $event_type['event_type'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($event_type['event_type']) ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="success">Status:</label>
                            <select name="success" id="success">
                                <option value="">All Status</option>
                                <option value="1" <?= $success_filter === '1' ? 'selected' : '' ?>>Success</option>
                                <option value="0" <?= $success_filter === '0' ? 'selected' : '' ?>>Failure</option>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label for="date">Date:</label>
                            <input type="date" name="date" id="date" value="<?= htmlspecialchars($date_filter) ?>">
                        </div>
                        
                        <div class="filter-buttons">
                            <button type="submit" class="btn btn-primary">Filter</button>
                            <a href="logs_viewer.php" class="btn btn-secondary">Clear</a>
                        </div>
                    </div>
                </form>
            </div>

            <div class="logs-table">
                <table>
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Event Type</th>
                            <th>User ID</th>
                            <th>Username</th>
                            <th>Details</th>
                            <th>Success</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($logs_result->num_rows > 0): ?>
                            <?php while ($log = $logs_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($log['timestamp']) ?></td>
                                    <td>
                                        <span class="event-type <?= htmlspecialchars($log['event_type']) ?>">
                                            <?= htmlspecialchars($log['event_type']) ?>
                                        </span>
                                    </td>
                                    <td><?= $log['user_id'] ? htmlspecialchars($log['user_id']) : 'N/A' ?></td>
                                    <td><?= htmlspecialchars($log['username']) ?></td>
                                    <td class="details-cell"><?= htmlspecialchars($log['details']) ?></td>
                                    <td>
                                        <span class="<?= $log['success'] ? 'success-yes' : 'success-no' ?>">
                                            <?= $log['success'] ? 'Yes' : 'No' ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center;">No logs found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($current_page > 1): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $current_page - 1])) ?>">Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $current_page - 2); $i <= min($total_pages, $current_page + 2); $i++): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" 
                           class="<?= $i === $current_page ? 'current' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($current_page < $total_pages): ?>
                        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $current_page + 1])) ?>">Next</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    document.getElementById("userDropdownBtn").addEventListener("click", function() {
        const dropdown = document.getElementById("userDropdownMenu");
        dropdown.style.display = dropdown.style.display === "block" ? "none" : "block";
    });

    window.addEventListener("click", function(event) {
        if (!event.target.closest(".user-dropdown")) {
            document.getElementById("userDropdownMenu").style.display = "none";
        }
    });
</script>
</body>
</html>
