<?php
class SecurityLogger {
    private $log_file;
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->log_file = __DIR__ . '/../logs/security.log';
        
        // Create logs directory if it doesn't exist
        $logs_dir = dirname($this->log_file);
        if (!is_dir($logs_dir)) {
            mkdir($logs_dir, 0755, true);
        }
    }
    
    public function logSecurityEvent($event_type, $user_id, $username, $details, $success = true) {
        $timestamp = date('Y-m-d H:i:s');
        $success_flag = $success ? 1 : 0;
        
        $this->logToDatabase($event_type, $user_id, $username, $details, $success_flag, $timestamp);
        $this->logToFile($event_type, $user_id, $username, $details, $success_flag, $timestamp);
    }
    
    public function logAuthAttempt($email, $success, $details = '') {
        $this->logSecurityEvent('AUTH_ATTEMPT', null, $email, $details, $success);
    }
    
    public function logAccessControlFailure($user_id, $username, $requested_resource, $details = '') {
        $full_details = "Access denied to: $requested_resource" . ($details ? " - $details" : '');
        $this->logSecurityEvent('ACCESS_DENIED', $user_id, $username, $full_details, false);
    }
    
    public function logValidationFailure($user_id, $username, $input_type, $input_value, $validation_rule, $details = '') {
        $full_details = "Validation failed for $input_type: '$input_value' - Rule: $validation_rule" . ($details ? " - $details" : '');
        $this->logSecurityEvent('VALIDATION_FAILURE', $user_id, $username, $full_details, false);
    }
    
    public function logPasswordChange($user_id, $username, $success, $details = '') {
        $this->logSecurityEvent('PASSWORD_CHANGE', $user_id, $username, $details, $success);
    }
    
    public function logAccountOperation($operation_type, $user_id, $username, $target_user_id, $target_username, $details = '') {
        $full_details = "Operation: $operation_type on user: $target_username" . ($details ? " - $details" : '');
        $this->logSecurityEvent('ACCOUNT_OPERATION', $user_id, $username, $full_details, true);
    }
    
    private function logToDatabase($event_type, $user_id, $username, $details, $success, $timestamp) {
        $sql = "INSERT INTO security_logs (event_type, user_id, username, details, success, timestamp) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sisis", $event_type, $user_id, $username, $details, $success, $timestamp);
        $stmt->execute();
        $stmt->close();
    }
    
    private function logToFile($event_type, $user_id, $username, $details, $success, $timestamp) {
        $status = $success ? 'SUCCESS' : 'FAILURE';
        $user_info = $user_id ? "User ID: $user_id" : "No User";
        $log_entry = "[$timestamp] [$status] [$event_type] $user_info | Username: $username | Details: $details\n";
        
        file_put_contents($this->log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }
    
    public static function getClientIP() {
        $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    }
}
?>
