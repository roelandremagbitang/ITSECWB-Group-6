<?php
include 'dependencies/config.php';
include 'dependencies/auth.php';

require_login();
require_role(['owner', 'admin']);

// Get filter parameters
$event_type_filter = $_GET['event_type'] ?? '';
$success_filter = $_GET['success'] ?? '';
$date_filter = $_GET['date'] ?? '';
$format = $_GET['format'] ?? 'csv';

// Build WHERE clause
$where_conditions = [];
$params = [];
$param_types = '';

if ($event_type_filter) {
    $where_conditions[] = "event_type = ?";
    $params[] = $event_type_filter;
    $param_types .= 's';
}

if ($success_filter !== '') {
    $where_conditions[] = "success = ?";
    $params[] = $success_filter;
    $param_types .= 'i';
}

if ($date_filter) {
    $where_conditions[] = "DATE(timestamp) = ?";
    $params[] = $date_filter;
    $param_types .= 's';
}

$where_clause = '';
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

// Get all logs for export
$logs_query = "SELECT * FROM security_logs $where_clause ORDER BY timestamp DESC";
$logs_stmt = $conn->prepare($logs_query);
if (!empty($params)) {
    $logs_stmt->bind_param($param_types, ...$params);
}
$logs_stmt->execute();
$logs_result = $logs_stmt->get_result();

if ($format === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="security_logs_' . date('Y-m-d_H-i-s') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // CSV headers
    fputcsv($output, ['Timestamp', 'Event Type', 'User ID', 'Username', 'Success', 'Details']);
    
    // CSV data
    while ($log = $logs_result->fetch_assoc()) {
        fputcsv($output, [
            $log['timestamp'],
            $log['event_type'],
            $log['user_id'] ?: 'N/A',
            $log['username'],
            $log['success'] ? 'Yes' : 'No',
            $log['details']
        ]);
    }
    
    fclose($output);
} else {
    header("Location: logs_viewer.php");
    exit();
}

$logs_stmt->close();
$conn->close();
?>
